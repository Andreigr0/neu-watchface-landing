'use strict';
const $ = id => document.getElementById(id);
const pageHeader=document.querySelector('header');
function syncHeaderHeight(){document.documentElement.style.setProperty('--header-height',pageHeader.offsetHeight+'px')}
syncHeaderHeight();
new ResizeObserver(syncHeaderHeight).observe(pageHeader);

const themeControl=$('theme-mode');
const themeModes=['system','light','dark'];
const themeIcons={
  system:'<circle cx="12" cy="12" r="7"/><path d="M12 1v2m0 18v2M1 12h2m18 0h2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/><path d="M11.2 7a5.1 5.1 0 0 0 5.8 6.4A5.2 5.2 0 1 1 11.2 7Z" fill="currentColor" stroke="none"/>',
  light:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
  dark:'<path d="M20.9 13A9 9 0 0 1 11 3.1 9 9 0 1 0 20.9 13Z"/>'
};
function updateThemeButton(){
  const mode=document.documentElement.dataset.theme||'system';
  const next=themeModes[(themeModes.indexOf(mode)+1)%themeModes.length];
  const label=s=>s[0].toUpperCase()+s.slice(1);
  themeControl.querySelector('svg').innerHTML=themeIcons[mode];
  themeControl.setAttribute('aria-label',`Theme: ${label(mode)}. Switch to ${label(next)}.`);
  themeControl.title=`${label(mode)} theme · Switch to ${label(next)}`;
}
updateThemeButton();
themeControl.addEventListener('click',()=>{
  const current=document.documentElement.dataset.theme||'system';
  const next=themeModes[(themeModes.indexOf(current)+1)%themeModes.length];
  document.documentElement.dataset.theme=next;
  try{localStorage.setItem('neu-theme',next)}catch{}
  updateThemeButton();
});
const sceneDefinitions = {
  venu4: {name:'Venu 4',display:'454 × 454 AMOLED',time:'08:37:20',top:[1,18,25,3,7],count:3,side:-1,bars:[0,1,2],values:{1:'18°C',18:'6842',25:'6h',4:'82',17:'1480'}},
  vivoactive5: {name:'vívoactive 5',display:'390 × 390 AMOLED',time:'10:09:36',top:[8,5,13,11,12],count:5,side:1,bars:[5,6,8],values:{1:'21°C',8:'8',5:'98%',13:'3',11:'64%',12:'12 SE',7:'6.4',9:'24',22:'420'}},
  fenix7x: {name:'fēnix 7X',display:'280 × 280 MIP',time:'16:24:08',top:[0,4,2,7,18],count:4,side:19,bars:[0,1,2],values:{0:'76',4:'64',2:'68',7:'7.2',18:'8600',17:'1870'}}
};
const metricNames = ['Battery','Weather','Heart rate','Stress','Body Battery','SpO₂','Respiration','Distance','Floors','Daily active minutes','Altitude','Humidity','Wind','UV index','Sunrise / sunset','Sunset','Pressure','Total calories','Steps','VO₂ max','HRV','Notifications','Active calories','Precipitation','Solar intensity','Recovery','Week number','Weight','Weekly active minutes','Second time zone','Training status','Calendar event','Move bar','Weekly distance','Water consumed','Sunrise'];
// Matches the actual on-watch pickers, rather than the broader legacy renderer IDs.
const metricGroups = {Activity:[18,7,8,9,17,22,33,28],Health:[2,4,3,5,6,25,27],Weather:[1,11,12,13,23,16,10],Tracking:[34],'Time & other':[14,15,35,0,19,26,29,24,31]};
const barNames = ['Body Battery','Steps','Total calories','Water','Floors','Active minutes','Distance','Vigorous minutes','Active calories','Weekly active minutes','Weekly distance'];
const barMetrics = [4,18,17,34,8,9,7,9,22,28,33];
const barIcons = ['BodyBatteryBiggerIcon','StepsBiggerIcon','CaloriesBiggerIcon','WaterLevelBiggerIcon','FloorsBarBiggerIcon','ActiveMinutesBarBiggerIcon','DistanceBarBiggerIcon','VigorousMinutesBarBiggerIcon','ActiveCaloriesBarBiggerIcon','WeeklyIntensityBarBiggerIcon','WeeklyDistanceBarBiggerIcon'];
const iconNames = ['EnergyIcon','WeatherPartlyCloudy','HeartIcon','StressLevelIcon','BodyBatteryBigIcon','Spo2Icon','RespirationIcon','DistanceTopIcon','FloorsTopIcon','ActiveMinutesTopIcon','AltitudeIcon','HumidityIcon','WindSpeedIcon','UvIndexIcon','SunriseIcon','SunsetIcon','PressureIcon','CaloriesTopIcon','StepsTopIcon','Vo2MaxIcon',null,null,'ActiveCaloriesTopIcon','PrecipitationTopIcon','SolarIntensityTopIcon','RecoveryTopIcon','WeekNumberTopIcon','WeightTopIcon','WeeklyIntensityTopIcon','AltTimezoneTopIcon',null,'CalendarEventTopIcon',null,'WeeklyDistanceTopIcon','WaterLevelTopIcon','SunriseIcon'];
const colours = ['#4CAF50','#2196F3','#FF9800','#FF0000','#00BCD4','#FFEB3B'];
const extraColours = ['#FFFFFF','#B0BEC5','#607D8B','#FFCDD2','#EF5350','#C62828','#F8BBD0','#EC407A','#AD1457','#E1BEE7','#AB47BC','#6A1B9A','#C5CAE9','#5C6BC0','#283593','#90CAF9','#80DEEA','#00838F','#A5D6A7','#2E7D32','#DCE775','#FFF59D','#FFCC80','#8D6E63'];
const timeColours = ['#54FD9D','#FF0000','#EDE8D0','#48D1CC',null,'#FFFF3C','#FCFCFC'];
const colourNames = ['Green','Blue','Orange','Red','Cyan','Yellow'];
const styleNames = ['Green gradient','Red & white','Cream','Teal',null,'Yellow','White'];
const styleSwatches = ['#4bff9e','#ff5353','#ffeccb','#39dcca',null,'#ffeb3b','#fff'];
const styleFolders = ['numbers','numbers_red','numbers_cream','numbers_teal',null,'numbers_yellow_flat','numbers_white'];
const samples = {0:'76',1:'18°C',2:'68',3:'24',4:'82',5:'98%',6:'14',7:'7.2',8:'8',9:'24',10:'120m',11:'64%',12:'12 SE',13:'3',14:'18:42',15:'18:42',16:'760',17:'1480',18:'6842',19:'48',22:'420',23:'20%',24:'--',25:'6h',26:'40',27:'72.5',28:'128',31:'14:30',33:'32.4',35:'06:21'};
let data, currentScene='venu4', state, selectedFeature='top', changed=false, renderRevision=0;
const configurationKey='neu-preview-config-v1';
let savedConfigurations={version:1,scene:'venu4',scenes:{}};
try {
  const saved=JSON.parse(localStorage.getItem(configurationKey));
  if(saved?.version===1&&Object.hasOwn(sceneDefinitions,saved.scene)&&saved.scenes&&typeof saved.scenes==='object')savedConfigurations=saved;
} catch {}
function persistConfigurations() {
  savedConfigurations.scene=currentScene;
  try {localStorage.setItem(configurationKey,JSON.stringify(savedConfigurations));} catch {}
}
function saveConfiguration() {
  savedConfigurations.scenes[currentScene]=structuredClone(state);
  persistConfigurations();
}
function validConfiguration(saved,defaults) {
  if(!saved||typeof saved!=='object')return false;
  const hex=v=>typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v);
  for(const [key,value] of Object.entries(defaults)) {
    if(typeof value==='boolean'&&typeof saved[key]!=='boolean')return false;
    if(typeof value==='number'&&!Number.isFinite(saved[key]))return false;
  }
  const ranges={count:[0,5],side:[-1,35],barCount:[0,3],style:[0,7],timezone:[-11,12],notificationCount:[0,99],activeCaloriesGoal:[100,5000],water:[0,Number.MAX_SAFE_INTEGER],waterGoal:[500,5000],serving:[50,1000]};
  for(const [key,[min,max]] of Object.entries(ranges))if(!Number.isInteger(saved[key])||saved[key]<min||saved[key]>max)return false;
  if(![0,3,4,5].includes(saved.count)||![0,3].includes(saved.barCount)||saved.style===4)return false;
  if(typeof saved.time!=='string'||!/^([01]\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(saved.time))return false;
  if(!hex(saved.timeCustom)||!hex(saved.timeCustom2))return false;
  for(const [key,length,max] of [['top',5,35],['bars',3,10]])if(!Array.isArray(saved[key])||saved[key].length!==length||!saved[key].every(v=>Number.isInteger(v)&&v>=0&&v<=max))return false;
  if(!Array.isArray(saved.barColours)||saved.barColours.length!==3||!saved.barColours.every(v=>hex(v)||(Number.isInteger(v)&&v>=0&&v<6)))return false;
  if(!Array.isArray(saved.barCustoms)||saved.barCustoms.length!==3||!saved.barCustoms.every(hex))return false;
  return Array.isArray(saved.sharedColours)&&saved.sharedColours.every(hex);
}
const images = new Map();
const ctx = $('face').getContext('2d');
function imageAsset(url) {
  if (!images.has(url)) images.set(url,new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error(`Image unavailable: ${url}`));img.src=url;}));
  return images.get(url);
}
function metricOptions(value,allowOff=false) {
  let html=allowOff?`<option value="-1"${value===-1?' selected':''}>Off</option>`:'';
  for(const [group,ids] of Object.entries(metricGroups)) html+=`<optgroup label="${group}">${ids.map(id=>`<option value="${id}"${id===value?' selected':''}>${metricNames[id]}</option>`).join('')}</optgroup>`;
  return html;
}
function currentTimeColour() { return state.style===7?state.timeCustom:timeColours[state.style]; }
function barColour(i) { return typeof state.barColours[i]==='string'?state.barColours[i]:colours[state.barColours[i]]; }
function colourSwatch(rgb,target,selected,style=null) {
  const background=style===0?'linear-gradient(#8b8b8b, #54fd9d 35%)':style===1?'linear-gradient(#aaa9,transparent 35%),linear-gradient(90deg,#f00 50%,#fcfcfc 50%)':style===6?'linear-gradient(#acacac,#fcfcfc 35%)':rgb;
  return `<button type="button" class="swatch" data-colour-target="${target}" data-rgb="${rgb}"${style!==null?` data-time-preset="${style}"`:''} aria-label="${style!==null?styleNames[style]:rgb}" aria-pressed="${selected}" title="${style!==null?styleNames[style]:rgb}" style="background:${background}"></button>`;
}
function colourPalette(target) {
  const minutes=target==='minutes',time=target==='time'||minutes, selected=minutes?state.timeCustom2:time?currentTimeColour():barColour(Number(target));
  const presets=minutes?'':time?[0,1,6,2,3,5].map(i=>colourSwatch(timeColours[i],target,state.style===i,i)).join(''):colours.map((rgb,i)=>colourSwatch(rgb,target,state.barColours[Number(target)]===i)).join('');
  const rgbs=[...new Set([...extraColours,...state.sharedColours])].filter(rgb=>time||!colours.includes(rgb));
  const id=`colour-${target}`;
  return `<div class="colour-palette" role="group" aria-label="${minutes?'Minutes':time?'Time':'Bar '+(Number(target)+1)} colour palette">${presets}${rgbs.map(rgb=>colourSwatch(rgb,target,selected===rgb&&(time?state.style===7:typeof state.barColours[Number(target)]==='string'))).join('')}</div><div class="custom-colour"><label for="${id}-picker">${minutes?'Minutes colour':time&&state.timePair?'Hours colour':'Custom colour'}<input id="${id}-picker" type="color" data-custom-target="${target}" value="${selected}"></label><label for="${id}-hex">HEX<input id="${id}-hex" type="text" data-custom-target="${target}" value="${selected}" pattern="#?[0-9a-fA-F]{6}" maxlength="7" spellcheck="false" autocapitalize="characters"></label></div>`;
}
function setCustomColour(target,rgb) {
  if(target==='time'){state.style=7;state.timeCustom=rgb;}
  else if(target==='minutes'){state.style=7;state.timePair=true;state.timeCustom2=rgb;}
  else {const i=Number(target);state.barColours[i]=rgb;state.barCustoms[i]=rgb;}
}
function controlsFromState() {
  // Keep committed shared swatches in insertion order, independently of which
  // target currently uses them. Live picker input does not rebuild this list.
  for(const rgb of [state.timeCustom,...(state.timePair?[state.timeCustom2]:[]),...state.barCustoms,currentTimeColour(),...state.barColours.map((_,i)=>barColour(i))]) {
    if(!state.sharedColours.includes(rgb))state.sharedColours.push(rgb);
  }
  const focused=document.activeElement,focusId=focused?.id;
  const openBarColours=[...document.querySelectorAll(".bar-colour-picker[open]")].map(el=>el.id);
  const ids = {'time-style':'style','demo-time':'time','top-count':'count','side-slot':'side','bar-count':'barCount','timezone':'timezone','notification-count':'notificationCount','active-calories-goal':'activeCaloriesGoal'};
  for(const [id,key] of Object.entries(ids)) $(id).value=state[key];
  for(const [id,key] of Object.entries({'seconds':'seconds','twelve-hour':'twelve','large-labels':'large','imperial':'imperial','notifications':'notifications','alarm':'alarm','dnd':'dnd','no-bluetooth':'noBluetooth','water-enabled':'waterEnabled','time-shadow':'timeShadow'})) $(id).checked=state[key];
  $('side-slot').innerHTML=metricOptions(state.side,true);
  $('slot-settings').innerHTML=state.top.slice(0,state.count).map((id,i)=>`<label class="slot-setting">Slot ${i+1}<select id="preview-slot-${i}" data-slot="${i}">${metricOptions(id)}</select></label>`).join('');
  $('bar-settings').innerHTML=state.bars.slice(0,state.barCount).map((type,i)=>`<div class="bar-setting"><label>Bar ${i+1}<select id="preview-bar-${i}" data-bar="${i}">${barNames.map((name,id)=>`<option value="${id}"${type===id?' selected':''}>${name}</option>`).join('')}</select></label><details class="bar-colour-picker" id="bar-palette-${i}"><summary><span>Colour</span><span class="colour-dot" style="background:${barColour(i)}"></span><span>${barColour(i)}</span></summary>${colourPalette(String(i))}</details></div>`).join('');
  openBarColours.forEach(id=>{if($(id))$(id).open=true;});
  $('time-colours').innerHTML=colourPalette('time');
  $('time-pair').checked=state.style===7&&state.timePair;
  $('minute-colours').hidden=!$('time-pair').checked;
  $('minute-colours').innerHTML=colourPalette('minutes');
  $('time-shadow').disabled=currentScene==='fenix7x'||![0,1,6,7].includes(state.style);
  $('quick-swatches').innerHTML=styleNames.map((name,i)=>name?`<button class="swatch" data-style="${i}" aria-label="${name}" aria-pressed="${state.style===i}" style="background:${styleSwatches[i]}"></button>`:'').join('');
  const units=state.imperial?'oz':'ml';
  document.querySelectorAll('.unit-label').forEach(el=>el.textContent=`(${units})`);
  for(const [id,key] of [['water-goal','waterGoal'],['water-serving','serving'],['water-total','water']]) {
    const input=$(id);input.value=state.imperial?Math.round(state[key]/29.574):state[key];
    const range= id==='water-goal'?[500,5000,100]:id==='water-serving'?[50,1000,50]:[0,10000,1];
    input.min=state.imperial?Math.round(range[0]/29.574):range[0];input.max=state.imperial?Math.round(range[1]/29.574):range[1];input.step=state.imperial?1:range[2];
  }
  $('add-water').disabled=$('remove-water').disabled=!state.waterEnabled;
  $('water-status').textContent=`${state.imperial?Math.round(state.water/29.574):state.water} ${units} / ${state.imperial?Math.round(state.waterGoal/29.574):state.waterGoal} ${units} · ${Math.round(Math.min(1,state.water/state.waterGoal)*100)}%`;
  if(focusId&&!focused.isConnected) $(focusId)?.focus({preventScroll:true});
}
function resetScene(id,restore=true) {
  currentScene=id;const s=sceneDefinitions[id];
  state={top:[...s.top],count:s.count,side:s.side,bars:[...s.bars],barCount:3,barColours:[0,1,2],style:0,sharedColours:['#54FD9D','#4CAF50','#2196F3','#FF9800'],timeCustom:'#54FD9D',timeCustom2:'#FCFCFC',timePair:false,barCustoms:['#4CAF50','#2196F3','#FF9800'],timeShadow:true,time:s.time,seconds:true,twelve:false,large:false,imperial:false,notifications:false,notificationCount:3,activeCaloriesGoal:250,waterEnabled:true,water:750,waterGoal:2000,serving:250,timezone:0,alarm:false,dnd:false,noBluetooth:false};
  const saved=savedConfigurations.scenes[id];
  if(restore&&validConfiguration(saved,state))state=Object.fromEntries(Object.keys(state).map(key=>[key,structuredClone(saved[key])]));
  changed=false;renderRevision++;
  const d=data.devices[id],box=$('watch-screen');
  $('device-skin').src=d.skin;$('device-skin').alt=`Garmin ${s.name} device skin`;
  for(const [key,val] of Object.entries({left:d.screen.x/d.width*100,top:d.screen.y/d.height*100,width:d.screen.width/d.width*100,height:d.screen.height/d.height*100})) box.style[key]=val+'%';
  $('capture').src=`assets/${id}.png`;$('capture').alt=`Original ${s.name} Garmin Simulator capture`;
  $('capture').hidden=false;$('face').hidden=true;
  $('device-name').textContent=`${s.name} · ${s.display}`;$('render-mode').textContent='Simulator capture';
  document.querySelectorAll('[data-scene]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.scene===id)));
  updatePreview('',true,false);
}
function featureStory() {
  const info={
    top:['Your top row','Choose three, four or five data fields, or switch the row off. Mix activity, health and weather readings in any combination.','Choose each field independently. Available readings depend on the watch.'],
    side:['One more reading','Keep a useful metric beside the time, or turn the side slot off. Choose from the same set of activity, health, weather and time fields.','A single-digit hour loses its leading zero when the side slot is enabled.'],
    date:['Your calendar, one press away','The date stays visible below the time. Press it to open the calendar on compatible watches.','The date recentres when the notification badge is hidden.'],
    alerts:['Notifications at a glance','Show a count beside the date, or switch it off. The badge only appears when there are unread notifications.','The notification badge has its own press target, separate from the date.'],
    bluetooth:['Phone connection, at a glance','The crossed-out Bluetooth icon appears when the watch is disconnected from your phone.','In 12-hour mode it sits to the left of the time, leaving AM or PM visible on the right.'],
    status:['Quiet mode. Alarm set.','An alarm indicator appears when an alarm is set. A separate Do Not Disturb indicator shows when quiet mode is enabled.','These indicators follow the watch’s status rather than a watch-face setting.'],
    bars:['Your goals, in colour','Show three progress bars, or turn them all off. Choose a metric and one of 30 ready-made colours for each bar, or create your own.','Track daily or weekly activity, energy and water. Goals use the watch’s data or your configured water and active calorie goals.'],
    time:['Time, with a personal touch','Choose a time style, one custom colour or separate colours for hours and minutes, with optional inner shadow on AMOLED. Show or hide seconds and switch between 12-hour and 24-hour time. In 12-hour mode, AM or PM appears beside the digits.','Enable water tracking to fill the digits as you drink. Assign water to a progress bar to show it there instead.']
  };
  const [title,copy,hint]=info[selectedFeature];$('feature-title').textContent=title;$('feature-copy').textContent=copy;$('feature-hint').textContent=hint;
  const groups=selectedFeature==='top'||selectedFeature==='side'?Object.entries(metricGroups):selectedFeature==='bars'?[['Metrics',barNames],['Colours',['30 ready-made colours','Custom HEX','Shared saved colours']]]:selectedFeature==='time'?[['Time styles',[...styleNames.filter(Boolean),'Custom HEX','Two custom time colours','Optional inner shadow']]]:[];
  $('feature-options').innerHTML=groups.map(([name,items])=>`<div class="option-group"><h4>${name}</h4><p>${items.map(x=>typeof x==='number'?metricNames[x]:x).join(' · ')}</p></div>`).join('');
  document.querySelectorAll('[data-feature]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.feature===selectedFeature)));
}
function drawConnector() {
  if(!data)return;const d=data.devices.venu4,s=d.screen,f=s.width/454;
  const layout=anatomyLayout||{dateStart:105,dateWidth:190,badgeX:327,secondsX:381};
  const regions={top:[78,49,320,78],side:[14,162,55,77],date:[layout.dateStart-5,249,layout.dateWidth+10,48],alerts:[layout.badgeX-24,249,48,48],bluetooth:layout.bluetoothBounds||[53,220,28,33],status:[layout.secondsX-3,141,57,26],bars:[91,315,265,91],time:[88,141,layout.secondsX-92,106]};
  const [x,y,w,h]=regions[selectedFeature],rx=s.x+x*f,ry=s.y+y*f,rw=w*f,rh=h*f;
  const labels={top:'TOP ROW',side:'SIDE SLOT',date:'DATE',alerts:'NOTIFICATIONS',bluetooth:'NO BLUETOOTH',status:'ALARM & DND',bars:'YOUR PROGRESS',time:'TIME & WATER'};
  const top=selectedFeature==='top',bottom=selectedFeature==='bars';
  const tx=d.width*.035;
  const ty=bottom?d.height*.935:s.y*.45;
  const ax=top?rx+rw*.26:bottom?rx+rw*.7:rx,ay=top?ry:bottom?ry+rh:ry+rh*.5;
  const svg=$('callout-line');svg.setAttribute('viewBox',`0 0 ${d.width} ${d.height}`);
  svg.innerHTML=`<rect x="${rx}" y="${ry}" width="${rw}" height="${rh}" rx="8" fill="none" stroke="#4bff9e" stroke-width="2"/><path d="M ${tx} ${ty+9} L ${tx} ${ay+(top?-20:bottom?20:0)} L ${ax} ${ay}" fill="none" stroke="#676772" stroke-width="1.5"/><circle cx="${ax}" cy="${ay}" r="3" fill="#4bff9e"/><rect x="${tx-6}" y="${ty-d.width*.032}" width="${labels[selectedFeature].length*d.width*.025}" height="${d.width*.042}" rx="3" fill="#fff" fill-opacity=".94"/><text x="${tx}" y="${ty}" fill="#303039" font-family="Arial,sans-serif" font-size="${d.width*.038}" font-weight="700" letter-spacing="1">${labels[selectedFeature]}</text>`;
}
function selectFeature(feature) {selectedFeature=feature;featureStory();drawConnector();}
function updatePreview(message='',syncControls=true,persist=true) {
  changed=true;if(syncControls)controlsFromState();if(persist)saveConfiguration();featureStory();drawConnector();$('interaction-status').textContent=message;renderFace().catch(error=>{$('interaction-status').textContent='A preview asset could not be loaded. Reset this setup to see its simulator capture.';console.error(error);});
}
function swapMetric(index,next) {
  const old= index==='side'?state.side:state.top[index];
  const other=state.top.slice(0,state.count).findIndex((v,i)=>v===next&&i!==index);
  if(next>=0&&other>=0)state.top[other]=old<0?Object.values(metricGroups).flat().find(id=>!state.top.includes(id)&&id!==next):old;
  else if(index!=='side'&&state.side===next)state.side=old;
  if(index==='side')state.side=next;else state.top[index]=next;
}
function serving(direction) {
  if(!state.waterEnabled)return;
  state.water=Math.max(0,state.water+state.serving*direction);
  updatePreview(direction>0?'One serving added to this local preview.':'One serving subtracted from this local preview.');
}
async function drawWatch(deviceId,config) {
  const currentScene=deviceId,state=config;
function valueOf(type) {
  const v={...samples,...sceneDefinitions[currentScene].values};
  if(type===22){
    const [h,m,s]=state.time.split(':').map(Number),seconds=h*3600+m*60+(s||0);
    const resting=2110;
    return String(Math.max(0,Math.round(Number(v[17])-resting*seconds/86400)));
  }
  if(type===34)return String(state.imperial?Math.round(state.water/29.574):state.water);
  if(type===29){const [h,m]=state.time.split(':').map(Number);return String((h+state.timezone+24)%24).padStart(2,'0')+':'+String(m).padStart(2,'0');}
  if(state.imperial){
    if(type===1)return Math.round(parseFloat(v[1])*9/5+32)+'°F';
    if(type===7||type===33)return (parseFloat(v[type])/1.609344).toFixed(1);
    if(type===10)return '394F';if(type===16)return '29.9';if(type===27)return '160';if(type===12)return '7 SE';
  }
  return v[type]??'--';
}
// Original bitmap fonts and icons are rendered at their native size, scaled to a shared 454-unit layout.
function fontMetric(name,text) {
  const size=data.devices[currentScene].size,font=data.fonts[size][name],scale=454/size;
  if(!font)return {width:0,height:0};
  return {width:[...text].reduce((sum,c)=>sum+(font.chars[c.codePointAt(0)]?.xadvance??0)*scale,0),height:font.lineHeight*scale};
}
async function fontText(context,name,text,x,y,align='left',tint=null) {
  const size=data.devices[currentScene].size,font=data.fonts[size][name];if(!font)return;
  const factor=454/size,measure=fontMetric(name,text),atlas=await imageAsset(font.image);
  const temp=document.createElement('canvas');temp.width=Math.ceil(measure.width+4);temp.height=Math.ceil(measure.height+4);const tc=temp.getContext('2d');
  let advance=0;for(const c of text){const g=font.chars[c.codePointAt(0)];if(!g)continue;tc.drawImage(atlas,g.x,g.y,g.width,g.height,advance+g.xoffset*factor,g.yoffset*factor,g.width*factor,g.height*factor);advance+=g.xadvance*factor;}
  if(tint){
    // Some Garmin BMFont atlases have opaque black backgrounds; black is the mask, not ink.
    const pixels=tc.getImageData(0,0,temp.width,temp.height);
    for(let i=0;i<pixels.data.length;i+=4) pixels.data[i+3]*=Math.max(pixels.data[i],pixels.data[i+1],pixels.data[i+2])/255;
    tc.putImageData(pixels,0,0);tc.globalCompositeOperation='source-in';tc.fillStyle=tint;tc.fillRect(0,0,temp.width,temp.height);
  }
  context.drawImage(temp,align==='center'?x-measure.width/2:align==='right'?x-measure.width:x,y);
}
async function icon(context,name,x,y) {
  const size=data.devices[currentScene].size,url=data.icons[size][name];if(!url)return {width:0,height:0};
  const im=await imageAsset(url),f=454/size;context.drawImage(im,x,y,im.width*f,im.height*f);return {width:im.width*f,height:im.height*f};
}
async function drawSlot(context,type,centerX,iconY,textY,font) {
  const size=data.devices[currentScene].size,url=data.icons[size][iconNames[type]];
  if(url){const im=await imageAsset(url),f=454/size;context.drawImage(im,centerX-20,iconY,im.width*f,im.height*f);}
  await fontText(context,font,valueOf(type),centerX,textY,'center');
}
function barData(type) {
  const val=parseFloat(valueOf(barMetrics[type]));const raw={...samples,...sceneDefinitions[currentScene].values};
  const percentages=[Number(raw[4])/100,Number(raw[18])/10000,Number(raw[17])/2400,state.water/state.waterGoal,Number(raw[8])/10,Number(raw[9])/30,Number(raw[7])/10,12/15,Number(valueOf(22))/state.activeCaloriesGoal,Number(raw[28])/150,Number(raw[33])/56];
  return {pct:Math.min(1,Math.max(0,percentages[type]||0)),label:type===7?'12':valueOf(barMetrics[type])};
}
async function paint() {
  const off=document.createElement('canvas');off.width=off.height=454;const c=off.getContext('2d');c.fillStyle='#000';c.fillRect(0,0,454,454);
  const device=data.devices[currentScene],native=device.size,factor=454/native,mip=currentScene==='fenix7x';
  let [hour,min,sec]=state.time.split(':').map(Number);const actualHour=hour;
  if(state.twelve)hour=hour%12||12;
  const hs=(hour<10&&(state.side>=0||state.twelve))?String(hour):String(hour).padStart(2,'0'),ms=String(min).padStart(2,'0');
  const waterPct=state.waterEnabled&&!state.bars.includes(3)?Math.min(1,state.water/state.waterGoal):0;
  let secondsX=381,digitHeight=132,hourStart=88,bluetoothBounds=null;
  if(!mip){
    const flat=state.timeShadow===false&&[0,1,6,7].includes(state.style);
    const folder=flat?'time_flat':state.style===7?'numbers_white':styleFolders[state.style],minuteFolder=state.style===1&&!flat?'numbers_white':folder;
    const path=(fld,char)=>`assets/res-${native}/drawables/${fld}/${char}.png`;
    const hourDigits=await Promise.all([...hs].map(d=>imageAsset(path(folder,d))));const minuteDigits=await Promise.all([...ms].map(d=>imageAsset(path(minuteFolder,d))));
    const divider=await imageAsset(path(folder,'divider'));digitHeight=hourDigits[0].height*factor;
    const advance=im=>im.width*factor+4;
    let x=200-hourDigits.reduce((sum,im,i)=>sum+im.width*factor+(i?4:0),0);
    hourStart=x;
    const fillY=132+digitHeight*.12+digitHeight*.76*(1-waterPct);
    async function digit(im,x,y,char,fld){
      let artwork=im;
      if(state.style===7||flat){
        artwork=document.createElement('canvas');artwork.width=im.width;artwork.height=im.height;
        const tint=artwork.getContext('2d');tint.drawImage(im,0,0);
        const rgb=state.style===1&&fld===minuteFolder&&char!==':'&&x>=231?'#FCFCFC':state.style===7?(state.timePair&&x>=231?state.timeCustom2:state.timeCustom):timeColours[state.style];
        tint.globalCompositeOperation=flat?'source-in':'multiply';tint.fillStyle=rgb;tint.fillRect(0,0,im.width,im.height);
        if(!flat){tint.globalCompositeOperation='destination-in';tint.drawImage(im,0,0);}
      }
      c.drawImage(artwork,x,y,im.width*factor,im.height*factor);if(waterPct>0){const cyan=await imageAsset(path(state.style===3?'numbers_water_green':'numbers_cyan',char));c.save();c.beginPath();c.rect(x,fillY,im.width*factor,300-fillY);c.clip();c.drawImage(cyan,x,y,im.width*factor,im.height*factor);c.restore();}}
    for(let i=0;i<hs.length;i++){await digit(hourDigits[i],x,132,hs[i],folder);x+=advance(hourDigits[i]);}
    await digit(divider,205,129,'divider',folder);x=231;
    for(let i=0;i<ms.length;i++){await digit(minuteDigits[i],x,132,ms[i],minuteFolder);x+=advance(minuteDigits[i])-(i===0?2:0);}
    secondsX=x+6;
  }else{
    const palette=state.style===7?[state.timeCustom,state.timePair?state.timeCustom2:state.timeCustom]:[['#55ff9d','#55ff9d'],['#ff5555','#fff'],['#ffffd5','#ffffd5'],['#55ffff','#55ffff'],['#ffff55','#ffff55'],['#ffff55','#ffff55'],['#fff','#fff']][state.style];
    digitHeight=fontMetric('time_font','0').height;
    const timeLayer=document.createElement('canvas');timeLayer.width=timeLayer.height=454;const t=timeLayer.getContext('2d');
    let x=200-fontMetric('time_font',hs).width-(hs.length-1)*4;
    for(const char of hs){await fontText(t,'time_font',char,x,132,'left',palette[0]);x+=fontMetric('time_font',char).width+4;}
    await fontText(t,'time_font',':',205,129,'left',palette[0]);x=231;
    for(let i=0;i<ms.length;i++){await fontText(t,'time_font',ms[i],x,132,'left',palette[1]);x+=fontMetric('time_font',ms[i]).width+4-(i===0?2:0);}
    secondsX=x+6;c.drawImage(timeLayer,0,0);
    if(waterPct>0){t.globalCompositeOperation='source-in';t.fillStyle=state.style===3?'#55ff9d':'#0ff';t.fillRect(0,0,454,454);c.save();c.beginPath();const fill=132+digitHeight*.12+digitHeight*.76*(1-waterPct);c.rect(0,fill,454,300-fill);c.clip();c.drawImage(timeLayer,0,0);c.restore();}
  }
  if(state.seconds)await fontText(c,'seconds_font',String(sec||0).padStart(2,'0'),secondsX,132+(digitHeight-fontMetric('seconds_font','00').height)/2);
  let ampmSize=null;
  if(state.twelve){
    const suffix=['','Red','Cream','Teal','Yellow','Yellow','White','White'][state.style];
    ampmSize=await icon(c,(actualHour>=12?'PmIcon':'AmIcon')+suffix,secondsX,221);
  }
  if(state.noBluetooth){
    const x=state.twelve?hourStart-ampmSize.width+(hour<10?-2:4)+7:secondsX;
    const y=state.twelve?132+digitHeight-digitHeight*.12-ampmSize.height-4:217;
    const size=await icon(c,'NoBluetoothIcon',x,y);
    bluetoothBounds=[x-5,y-5,size.width+10,size.height+10];
  }
  if(state.alarm)await icon(c,'AlarmIcon',secondsX,145);
  if(state.dnd)await icon(c,'DoNotDisturbIcon',secondsX+(state.alarm?27:0),145);
  let start=state.count===5?102:121,end=state.count===5?354:334;
  if(state.large){const p=state.count===5?10:5;start-=p;end+=p;}
  if(state.count===3){const range=end-start;start+=range/6;end-=range/6;}
  for(let i=0;i<state.count;i++)await drawSlot(c,state.top[i],start+(end-start)*i/(state.count-1),56,state.large?94:97,state.large?'ui_font_top_big':'ui_font');
  if(state.side>=0){const x=actualHour<20?28:14;const iconSize=await icon(c,iconNames[state.side],x,state.large?174:175);await fontText(c,state.large?'ui_font_top_big':'ui_font',valueOf(state.side),x+(iconSize.width?iconSize.width/2:0),state.large?216:216,'center');}
  const date='TUE, 6 OCT',width=fontMetric('date_font',date).width,hasNotif=state.notifications&&state.notificationCount>0,total=width+(hasNotif?54:0),dateStart=(454-total)/2;
  await fontText(c,'date_font',date,dateStart,273-fontMetric('date_font',date).height/2);
  if(hasNotif){const x=dateStart+width+32;c.fillStyle=mip?'#555':'#282828';c.beginPath();c.arc(x,273,22,0,Math.PI*2);c.fill();await fontText(c,'circle_font',String(state.notificationCount),x,273-fontMetric('circle_font',String(state.notificationCount)).height/2,'center');}
  for(let i=0;i<state.barCount;i++){
    const y=323+i*31,bar=barData(state.bars[i]);c.fillStyle=mip?'#222':'#242424';c.strokeStyle='#484848';c.lineWidth=2;c.beginPath();c.roundRect(98,y-2,172,22,10);c.fill();c.stroke();
    const cs=mip?['#55aa55','#00aaff','#ffaa00','#f00','#00aaaa','#ff0']:colours;
    if(bar.pct>0){c.fillStyle=typeof state.barColours[i]==='string'?state.barColours[i]:cs[state.barColours[i]];c.beginPath();c.roundRect(100,y,Math.max(2,168*bar.pct),18,Math.min(8,84*bar.pct));c.fill();}
    const font=state.large?'ui_font_bot_big':'ui_font',h=fontMetric(font,bar.label).height,url=data.icons[native][barIcons[state.bars[i]]];let iconW=0;
    if(url){const im=await imageAsset(url);iconW=im.width*factor;c.drawImage(im,276,y+9-im.height*factor/2,iconW,im.height*factor);}
    await fontText(c,font,bar.label,276+iconW+4,y+9-h/2+1);
  }
  return {canvas:off,layout:{secondsX,bluetoothBounds,dateStart,dateWidth:width,badgeX:dateStart+width+32}};
}
  return paint();
}
async function renderFace() {
  const revision=++renderRevision;
  const result=await drawWatch(currentScene,structuredClone(state));
  if(revision!==renderRevision)return;
  ctx.clearRect(0,0,454,454);ctx.drawImage(result.canvas,0,0);
  $('face').hidden=false;$('capture').hidden=true;$('render-mode').textContent='Interactive preview';
  $('face').setAttribute('aria-label',`${sceneDefinitions[currentScene].name}, ${state.time}${state.twelve?(Number(state.time.split(':')[0])>=12?' PM':' AM'):''}, ${state.count} data slots, ${state.barCount} progress bars, water ${state.water} ml`);
}
const anatomyState={top:[0,1,2,4,18],count:5,side:19,bars:[0,1,2],barCount:3,barColours:[0,1,2],style:0,time:'12:59:20',seconds:true,twelve:false,large:false,imperial:false,notifications:true,notificationCount:5,activeCaloriesGoal:250,waterEnabled:false,water:750,waterGoal:2000,serving:250,timezone:0,alarm:true,dnd:true,noBluetooth:true};
let anatomyLayout=null;
async function renderAnatomy(){
  const result=await drawWatch('venu4',anatomyState);
  $('anatomy-face').getContext('2d').drawImage(result.canvas,0,0);
  anatomyLayout=result.layout;drawConnector();
  const hero=await drawWatch('venu4',{...anatomyState,seconds:false});
  $('hero-face').getContext('2d').drawImage(hero.canvas,0,0);
}
async function start() {
  data=await fetch('assets/preview-data.json').then(r=>{if(!r.ok)throw new Error('Preview data unavailable');return r.json();});
  $('timezone').innerHTML=Array.from({length:24},(_,i)=>i-11).map(v=>`<option value="${v}">${v>=0?'+':''}${v} hours</option>`).join('');resetScene(savedConfigurations.scene);await renderAnatomy();
  document.addEventListener('click',e=>{
    const button=e.target.closest('button');if(!button)return;
    if(button.dataset.colourTarget!==undefined){
      if(button.dataset.timePreset!==undefined){state.style=Number(button.dataset.timePreset);state.timePair=false;}
      else if(!['time','minutes'].includes(button.dataset.colourTarget)&&colours.includes(button.dataset.rgb))state.barColours[Number(button.dataset.colourTarget)]=colours.indexOf(button.dataset.rgb);
      else setCustomColour(button.dataset.colourTarget,button.dataset.rgb);
      updatePreview('Colour updated in this preview.');
    }
    if(button.dataset.scene){resetScene(button.dataset.scene);persistConfigurations();if(button.closest('#examples'))$('customise').scrollIntoView({behavior:'smooth',block:'start'});}
    if(button.dataset.feature)selectFeature(button.dataset.feature);
    if(button.dataset.style!==undefined){state.style=Number(button.dataset.style);state.timePair=false;selectFeature('time');updatePreview();}
    if(button.id==='reset-preview'){delete savedConfigurations.scenes[currentScene];persistConfigurations();resetScene(currentScene,false);}
    if(button.id==='add-water')serving(1);if(button.id==='remove-water')serving(-1);
  });
  $('watch-screen').addEventListener('click',e=>{
    if(e.target.closest('button'))return;
    const rect=$('watch-screen').getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*454,y=(e.clientY-rect.top)/rect.height*454;
    if(y>=56&&y<=115){selectFeature('top');return;}
    if(x<=60&&y>=160&&y<=230){selectFeature('side');return;}
    if(y>=130&&y<=240&&x>=60&&x<=400){selectFeature('time');if(state.waterEnabled)serving(1);return;}
    if(y>=245&&y<=300){selectFeature(x>=280?'alerts':'date');return;}
    if(y>=350&&x>=60&&x<=400){selectFeature('time');if(state.waterEnabled)serving(-1);return;}
    if(y>=315)selectFeature('bars');
  });
  // Reserve the tallest settings panel at this width. Closing an accordion
  // must not shorten the sticky preview's containing block or move its bottom.
  const settingsGrid=document.querySelector('#settings > .settings-grid');
  let settingsWidth=0,settingsHeight=0;
  new ResizeObserver(entries=>{
    const {width,height}=entries[0].contentRect;
    if(width!==settingsWidth){settingsWidth=width;settingsHeight=0;settingsGrid.style.removeProperty('--settings-height');}
    if(height>settingsHeight){settingsHeight=height;settingsGrid.style.setProperty('--settings-height',`${height}px`);}
  }).observe(settingsGrid);
  $('customise').addEventListener('input',e=>{
    const el=e.target;
    if(el.dataset.customTarget!==undefined&&/^#?[0-9a-f]{6}$/i.test(el.value)){
      const target=el.dataset.customTarget,rgb='#'+el.value.replace('#','').toUpperCase();
      setCustomColour(target,rgb);
      if(el.type==='color'){
        // Keep the native picker element alive throughout its input stream.
        // Rebuilding controls here closes the open browser colour picker.
        $(`colour-${target}-hex`).value=rgb;
        const palette=target==='minutes'?$('minute-colours'):target==='time'?$('time-colours'):$(`bar-palette-${target}`);
        palette.querySelectorAll('.swatch').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.timePreset===undefined&&button.dataset.rgb===rgb)));
        if(target==='time')$('quick-swatches').querySelectorAll('.swatch').forEach(button=>button.setAttribute('aria-pressed','false'));
        if(['time','minutes'].includes(target)){$('time-style').value=7;$('time-shadow').disabled=currentScene==='fenix7x';}
        else {
          const summary=$(`bar-palette-${target}`).querySelector('summary');
          summary.querySelector('.colour-dot').style.background=rgb;
          summary.lastElementChild.textContent=rgb;
        }
        updatePreview('Colour updated in this preview.',false);
      }else updatePreview('Colour updated in this preview.');
    } else if(el.type==='number'&&el.value!==''&&el.checkValidity()) {
      const value=Number(el.value);
      if(!Number.isFinite(value))return;
      const key={'notification-count':'notificationCount','active-calories-goal':'activeCaloriesGoal','water-goal':'waterGoal','water-serving':'serving','water-total':'water'}[el.id];
      if(!key)return;
      const water=el.id.startsWith('water-');
      state[key]=water&&state.imperial?Math.round(value*29.574):value;
      if(el.id==='water-goal')state.waterGoal=Math.min(5000,Math.max(500,state.waterGoal));
      if(el.id==='water-serving')state.serving=Math.min(1000,Math.max(50,state.serving));
      updatePreview('',false);
    } else if(el.id==='demo-time'&&el.value&&el.checkValidity()) {
      state.time=el.value.length===5?el.value+':00':el.value;
      updatePreview('',false);
    }
  });
  $('customise').addEventListener('change',e=>{
    const el=e.target,v=Number(el.value);
    if(el.dataset.customTarget!==undefined){
      if(!/^#?[0-9a-f]{6}$/i.test(el.value)){el.reportValidity();return;}
      setCustomColour(el.dataset.customTarget,'#'+el.value.replace('#','').toUpperCase());
    }
    else if(el.id==='time-pair'){
      state.timeCustom=currentTimeColour();state.timePair=el.checked;state.style=7;selectFeature('time');
    }
    else if(el.dataset.slot!==undefined){swapMetric(Number(el.dataset.slot),v);selectFeature('top');}
    else if(el.dataset.bar!==undefined){const i=Number(el.dataset.bar),old=state.bars[i],other=state.bars.slice(0,state.barCount).findIndex((x,j)=>x===v&&j!==i);if(other>=0)state.bars[other]=old;state.bars[i]=v;selectFeature('bars');}
    else if(el.dataset.barColour!==undefined){state.barColours[Number(el.dataset.barColour)]=v;selectFeature('bars');}
    else {
      const numeric={'time-style':'style','top-count':'count','bar-count':'barCount','timezone':'timezone','notification-count':'notificationCount','active-calories-goal':'activeCaloriesGoal'};
      const bools={'seconds':'seconds','twelve-hour':'twelve','large-labels':'large','imperial':'imperial','notifications':'notifications','alarm':'alarm','dnd':'dnd','no-bluetooth':'noBluetooth','water-enabled':'waterEnabled','time-shadow':'timeShadow'};
      if(numeric[el.id]){if(!Number.isFinite(v)||!el.checkValidity())return;state[numeric[el.id]]=v;}
      else if(bools[el.id])state[bools[el.id]]=el.checked;
      else if(el.id==='side-slot')swapMetric('side',v);
      else if(el.id==='demo-time'){if(!el.value||!el.checkValidity())return;state.time=el.value.length===5?el.value+':00':el.value;}
      else if(['water-goal','water-serving','water-total'].includes(el.id)){
        if(!Number.isFinite(v)||!el.checkValidity()){el.reportValidity();return;}const ml=state.imperial?Math.round(v*29.574):v;
        if(el.id==='water-goal')state.waterGoal=Math.min(5000,Math.max(500,ml));
        if(el.id==='water-serving')state.serving=Math.min(1000,Math.max(50,ml));
        if(el.id==='water-total'){state.water=ml;}
      }else return;
      if(el.id==='time-style'&&v!==7)state.timePair=false;
      if(['notifications','notification-count'].includes(el.id))selectFeature('alerts');
      else if(['alarm','dnd'].includes(el.id))selectFeature('status');else if(el.id==='no-bluetooth')selectFeature('bluetooth');else if(el.id==='top-count')selectFeature('top');else if(el.id==='side-slot')selectFeature('side');else if(['bar-count','active-calories-goal'].includes(el.id))selectFeature('bars');else selectFeature('time');
    }
    updatePreview();
  });
}
start().catch(error=>{$('interaction-status').textContent='The interactive preview needs a local web server. The original watch captures are still available.';console.error(error);});
